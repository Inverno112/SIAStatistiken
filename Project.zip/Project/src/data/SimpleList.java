package data;

import java.io.Serializable;
import java.util.List;

public class SimpleList<E> implements Serializable {
    private Node<E> head = null;
    private int size = 0;

    public SimpleList(){
    }

    public Node<E> getHead() {
        return this.head;
    }

    public int getSize(){
        return this.size;
    }

    public boolean isEmpty(){
        return this.size == 0;
    }

    public  SimpleList<E> fromListToSimpleList(List<E> list){
        SimpleList<E> newList = new SimpleList<>();
        for (E item: list){
            newList.addLast(item);
        }
        return newList;
    }

    public void add(E data){
        this.addLast(data);
    }

    public void addFirst(E data){
        Node<E> newNode = new Node<>(data);
        if (this.head == null){
            this.head = newNode;
            return;
        }
        newNode.setNext(this.head);
        this.head = newNode;
        this.size++;
    }

    public void addLast(E data){
        Node<E> newNode = new Node<>(data);
        if (this.head == null){
            this.head = newNode;
            return;
        }

        Node<E> ptr = this.head;
        while (ptr.getNext() != null) {
            ptr = ptr.getNext();
        }
        ptr.setNext(newNode);
        newNode.setNext(null);
        this.size++;
    }

    public void remove(E data){
        if (this.head == null){
            return;
        }

        if (this.head.getData().equals(data)) {
            removeFirst();
            return;
        }

        Node<E> deleteNode = null;
        Node<E> prev = null;
        for (Node<E> ptr = this.head; ptr != null; ptr = ptr.getNext()){
            if (data.equals(ptr.getData())){
                deleteNode = ptr;
                break;
            }
            prev = ptr;
        }
        if (deleteNode == null){
            return;
        }
        prev.setNext(deleteNode.getNext());
    }

    public E removeFirst(){
        if (this.head == null){
            return null;
        }
        Node<E> remove = this.head;
        this.head = this.head.getNext();
        remove.setNext(null);
        this.size --;
        return remove.getData();
    }

    public E removeLast(){
        if (this.head == null || this.head.getNext() == null){
            this.head = null;
            return null;
        }

        Node<E> ptr = this.head;
        while (ptr.getNext().getNext() != null){
            ptr = ptr.getNext();
        }

        Node<E> remove = ptr.getNext();
        ptr.setNext(null);
        this.size--;
        return remove.getData();
    }

    public E containsValue(Object data){
        for (Node<E> ptr = this.head; ptr != null; ptr = ptr.getNext()){
            if (data.equals(ptr.getData())){
                return ptr.getData();
            }
        }
        return null;
    }

    public String print(){
        StringBuilder info  = new StringBuilder();
        for (Node<E> ptr = this.head; ptr != null; ptr = ptr.getNext()){
            info.append(ptr.getData()).append(" ");
        }
        return info.toString();
    }
}
