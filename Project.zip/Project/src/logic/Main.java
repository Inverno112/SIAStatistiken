package logic;

import data.Course;
import data.DoubleList;
import data.Node;

public class Main {
    public static void main(String[] args) {
        long start = System.nanoTime();

        /*RandomData.setSize(5000);
        RandomData.generateInfo();*/

        FileManager.loadInfo("test_5000.obj");
        DoubleList<Course> info = FileManager.getInfo();
        for (Node<Course> ptr = info.getHead(); ptr != null; ptr = ptr.getNext()) {
            System.out.println(ptr.getData().getCourseCode() + ": " + ptr.getData().getCourseName());
        }
        System.out.println(info.getSize());


        /*// Get the saved info
        FileManager.loadInfo();
        AutoSIA.setCourses(FileManager.getInfo());

        DoubleList<Course> data = FileManager.getInfo();
        System.out.println(data.getSize());

        // Start threads
        ThreadCaller.initThreads();

        // Update the files with the new data
        FileManager.setInfo(AutoSIA.getCourses());
        FileManager.saveInfo();

        DoubleList<Course> d = FileManager.getInfo();
        System.out.println(d.getSize());*/

        long result = (System.nanoTime() - start)/1_000_000_000;
        System.out.println(result + " seg / " + result/60.0 + " min");



    }
}